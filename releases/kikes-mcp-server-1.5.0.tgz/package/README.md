# Kikes MCP Server

Servidor MCP local (stdio) con tres tools que llaman al webhook de Kikes para gestionar mensajes de Telegram.

## Tools

| Nombre | Parámetro | Descripción |
|---|---|---|
| `send_telegram_message` | `text_content` (string, 1–4096 caracteres, **en formato HTML de Telegram**) | Envía el mensaje. |
| `delete_last_telegram_message` | ninguno | Elimina el mensaje más reciente. No se puede deshacer. |
| `get_last_telegram_messages` | ninguno | Consulta los últimos 10 mensajes (contenido, ID del mensaje, ID del chat, fecha de creación y de actualización). Solo lectura. |

`send_telegram_message` y `delete_last_telegram_message` devuelven el mensaje que responda el endpoint (campo `message`, `mensaje` o `text` si es JSON, o el texto plano). Si no hay mensaje, devuelven uno por defecto (`Mensaje enviado correctamente.` / `Mensaje eliminado correctamente.`).

`get_last_telegram_messages` devuelve el JSON del endpoint indentado, sin renombrar campos. Si la respuesta viene vacía (cuerpo vacío, `[]` o `{}`), devuelve `No hay mensajes enviados.`, que no es un error.

Los errores HTTP y de red se devuelven como error de la tool.

Peticiones que realizan:

```
POST <TELEGRAM_WEBHOOK_URL>
Content-Type: application/json

{"text_content": "..."}
```

```
DELETE <TELEGRAM_WEBHOOK_URL>/delete-last-message
(sin body)
```

```
GET <TELEGRAM_WEBHOOK_URL sin el "/send" final>/get/lastest
```

## Instalación

```bash
npm install
npm run build
```

## Empaquetado e instalación en otro equipo

Generar el paquete (compila automáticamente antes de empaquetar):

```bash
npm pack --pack-destination releases
```

Crea `releases/kikes-mcp-server-<versión>.tgz`. Para usarlo en otro equipo (requiere Node 18 o superior):

```bash
npm install -g kikes-mcp-server-1.5.0.tgz
```

Esto instala el comando `kikes-mcp-server`. En la configuración de Claude Desktop se puede usar así:

```json
{
  "mcpServers": {
    "kikes": {
      "command": "kikes-mcp-server",
      "env": { "KIKES_AUTH": "<tu-clave>" }
    }
  }
}
```

Si el comando no se encuentra, usa la ruta completa a `node` y al `build/index.js` instalado (ver más abajo).

Para publicar una versión nueva, sube la versión en `package.json` (la del servidor se lee de ahí) y vuelve a empaquetar.

## Extensión de Claude Desktop (.mcpb)

Alternativa al paquete npm: un único archivo que se instala sin npm ni editar JSON.

```bash
npm run pack:mcpb
```

Genera `releases/kikes-mcp-server-<versión>.mcpb` (incluye las dependencias; unos 4 MB). Para instalarlo: doble clic en el archivo, arrastrarlo a la ventana de Claude Desktop, o *Settings > Extensions > Advanced settings > Install Extension…*. Al instalar, Claude Desktop muestra un formulario que pide la clave de autenticación (`kikes_auth`, campo sensible, obligatorio); ese valor se pasa al servidor como `KIKES_AUTH`.

El manifest está en `mcpb/manifest.json` y el script de empaquetado en `scripts/pack-mcpb.mjs`. La versión del manifest se toma siempre de `package.json`.

## Icono

El icono es `assets/icon.png`. Se usa en dos sitios:

- **Servidor MCP:** se incrusta como data URI en la información del servidor (`serverInfo.icons`). No hay confirmación de que Claude Desktop lo muestre para servidores lanzados desde `claude_desktop_config.json`.
- **Extensión .mcpb:** se copia como `icon.png` en la raíz del bundle y se referencia desde el manifest. Es la vía documentada por Anthropic (recomendado 512×512 px, mínimo 256×256, PNG con transparencia).

Para cambiarlo, reemplaza `assets/icon.png` y vuelve a empaquetar. El actual es provisional (320×320 px, tomado de `ti_logo.png`). Si falta el archivo, el servidor arranca igual sin icono.

## Configuración

Variables de entorno (se definen en el bloque `env` del conector de Claude):

- `KIKES_AUTH`: clave de autenticación. Su valor se envía en el header **`kikes_auth`** en todas las peticiones, tanto al dominio principal como al de respaldo. Si no se define, las peticiones van sin ese header (y el servidor registra un aviso por stderr). Solo admite ASCII imprimible: con otros caracteres el servidor no arranca. El valor nunca aparece en los mensajes de error ni en los logs.
- `TELEGRAM_WEBHOOK_URL`: URL del endpoint de envío (`.../telegram/send`). La de borrado se deriva añadiendo `/delete-last-message` y la de consulta cambiando el `/send` final por `/get/lastest`. Si no se define, usa la URL de ngrok incluida en `src/index.ts`. Los dominios gratuitos de ngrok pueden cambiar; si cambia, define esta variable en lugar de recompilar.

- `TELEGRAM_FALLBACK_HOST`: dominio de respaldo (por defecto `darn-trapdoor-survivor.ngrok-free.dev`). Si vale `""` (vacío), el reintento se desactiva. Admite `host:puerto`.

### Reintento automático con el dominio de respaldo

Es interno: Claude solo ve el resultado final. Se repite la misma petición (mismo método y ruta) cambiando únicamente el dominio.

| Situación en el dominio principal | ¿Reintenta con el respaldo? |
|---|---|
| Fallo de conexión (DNS, conexión rechazada, etc.) | Sí |
| Túnel de ngrok caído (HTTP 404 con cabecera `Ngrok-Error-Code`, p. ej. `ERR_NGROK_3200`) | Sí |
| Timeout (10 s) en la consulta (`GET`) | Sí |
| Timeout (10 s) al enviar o eliminar (`POST`/`DELETE`) | **No**: la petición pudo procesarse y reintentar duplicaría el mensaje o borraría otro. La tool avisa de que se verifique antes de reintentar. |
| Error HTTP normal (400, 500, etc.) | No: el servidor sí recibió la petición |

Si ambos dominios fallan, el error indica el motivo de cada uno.

### Claude Desktop

Edita `%APPDATA%\Claude\claude_desktop_config.json` y reinicia Claude Desktop:

```json
{
  "mcpServers": {
    "kikes": {
      "command": "node",
      "args": ["C:\\Users\\juan.cristancho\\Documents\\Kikes MCP Server\\build\\index.js"],
      "env": { "KIKES_AUTH": "<tu-clave>" }
    }
  }
}
```

Para fijar otra URL añade `"TELEGRAM_WEBHOOK_URL": "https://..."` dentro de `env`.

### Claude Code

```bash
claude mcp add kikes -e KIKES_AUTH=<tu-clave> -- node "C:\Users\juan.cristancho\Documents\Kikes MCP Server\build\index.js"
```

## Autenticación

Las peticiones llevan el header `kikes_auth: <valor de KIKES_AUTH>`. Quien reciba la petición (n8n) debe validarlo; este servidor solo lo envía.

- Si el endpoint responde 401 o 403, la tool lo indica y avisa si falta configurar `KIKES_AUTH` o si su valor es incorrecto.
- No se siguen redirecciones HTTP, para que la clave no pueda reenviarse a otro host.
- Algunos proxies inversos (nginx por defecto) descartan los headers con guion bajo. Si el endpoint nunca ve `kikes_auth`, revisa ese punto.
- La clave queda en texto plano en el archivo de configuración de Claude. El paquete no la incluye, pero sí las URLs de ngrok.

## Notas

- La protección real depende de que el endpoint valide `kikes_auth`: si no lo hace, quien conozca la URL puede enviar mensajes.
- Tiempo máximo de espera: 10 s.
- stdout está reservado para el protocolo MCP; los logs salen por stderr.
